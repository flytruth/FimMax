---
name: Bug report
about: Report a defect in wazuh-fim-telegram
title: "[bug] "
labels: bug, needs-triage
---

## What happened?

<!-- Short description of the problem. -->

## What did you expect?

## Steps to reproduce

1.
2.
3.

## Environment

- wazuh-fim-telegram version:
- Wazuh version:
- Python version:
- Deployment (Docker / systemd / bare script):

## Logs

<details><summary>logs</summary>

```
paste relevant log lines here
```

</details>

## Configuration (redact secrets!)

<details><summary>config</summary>

```
.env (redacted) + config/rules.yaml
```

</details>
