---
name: Feature request
about: Suggest a new feature or improvement
title: "[feat] "
labels: enhancement, needs-triage
---

## What

<!-- One-sentence description of the feature. -->

## Why

<!-- Use case / pain point. -->

## How (sketch)

<!-- Rough implementation idea: which module changes, new env vars, etc. -->

## Alternatives considered
