## Pull request template

### Summary

<!-- What does this PR change, in one or two sentences? -->

### Motivation

<!-- Why is this change needed? Link issues if any: Closes #123 -->

### Changes

<!-- Bullet list of concrete changes. -->
-

### Checklist

- [ ] Tests added / updated
- [ ] `ruff check` + `ruff format --check` pass locally
- [ ] `mypy` passes
- [ ] `pytest` passes
- [ ] If behaviour changed: README / docs updated
- [ ] No secrets / tokens committed

### Notes for reviewer

<!-- Anything the reviewer should pay extra attention to. -->
